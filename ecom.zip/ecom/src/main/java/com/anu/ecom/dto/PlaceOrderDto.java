package com.anu.ecom.dto;

import lombok.Data;

@Data
public class PlaceOrderDto 
{
	private Long userId;
	private String address;
	private String orderDescription;
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getOrderDescription() {
		return orderDescription;
	}
	public void setOrderDescription(String orderDescription) {
		this.orderDescription = orderDescription;
	}
	

}
