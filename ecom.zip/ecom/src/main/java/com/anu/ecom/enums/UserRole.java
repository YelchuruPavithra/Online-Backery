package com.anu.ecom.enums;

public enum UserRole 
{
	ADMIN,
	CUSTOMER
}
