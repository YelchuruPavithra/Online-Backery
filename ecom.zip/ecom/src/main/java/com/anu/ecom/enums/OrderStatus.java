package com.anu.ecom.enums;

public enum OrderStatus {
	
	Pending,
	Placed,
	Shipped,
	Delivered

}
